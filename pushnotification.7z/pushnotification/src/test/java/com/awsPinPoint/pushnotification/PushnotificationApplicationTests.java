package com.awsPinPoint.pushnotification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PushnotificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
